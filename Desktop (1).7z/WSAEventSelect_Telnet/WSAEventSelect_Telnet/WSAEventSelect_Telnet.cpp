// WSAEventSelect_Telnet.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <WinSock2.h>
#include <Windows.h>
#include <malloc.h>

SOCKET* client_sockets = NULL;
WSAEVENT* client_event = NULL;
int nclient = 0;
bool* client_login = NULL;

SOCKET s;
WSAEVENT se;
char* login = "Dang nhap thanh cong. Hay gui lenh de thuc thi\n";
char* invalid = "Sai cu phap dang nhap!\n";

int main(int argc, char* argv[])
{
	WSADATA DATA;
	WSAStartup(MAKEWORD(2, 2), &DATA);
	s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	SOCKADDR_IN saddr;
	SOCKADDR_IN caddr;
	saddr.sin_family = AF_INET;
	saddr.sin_port = htons(8888);
	saddr.sin_addr.S_un.S_addr = htonl(INADDR_ANY);
	bind(s, (sockaddr*)&saddr, sizeof(saddr));
	listen(s, 10);
	se = WSACreateEvent();
	WSAEventSelect(s, se, FD_ACCEPT);

	while (true)
	{
		WSAEVENT* events = (WSAEVENT*)calloc(nclient + 1, sizeof(WSAEVENT));
		events[0] = se;
		for (int i = 0; i < nclient; i++)
		{
			events[i + 1] = client_event[i];
		}
		DWORD k = WSAWaitForMultipleEvents(nclient + 1, events, FALSE, INFINITE, TRUE);
		k -= WSA_WAIT_EVENT_0;
		int ntmp = nclient;
		for (int i = k; i < ntmp + 1; i++)
		{
			DWORD j = WSAWaitForMultipleEvents(1, &events[i], FALSE, 100, TRUE);
			if (j != WSA_WAIT_FAILED && j != WSA_WAIT_TIMEOUT)
			{
				WSAResetEvent(events[i]); //Dong khoa lai
				if (i == 0) //SOCKET s
				{
					int clen = sizeof(caddr);
					SOCKET c = accept(s, (sockaddr*)&caddr, &clen);
					client_sockets = (SOCKET*)realloc(client_sockets, (nclient + 1) * sizeof(SOCKET));
					client_login = (bool*)realloc(client_login, (nclient + 1) * sizeof(bool));
					client_event = (WSAEVENT*)realloc(client_event, (nclient + 1) * sizeof(WSAEVENT));
					client_sockets[nclient] = c;
					client_login[nclient] = false;
					client_event[nclient] = WSACreateEvent();
					WSAEventSelect(client_sockets[nclient], client_event[nclient], FD_READ);
					nclient += 1;
				}
				else
				{
					char buffer[1024];
					memset(buffer, 0, sizeof(buffer));
					recv(client_sockets[i - 1], buffer, sizeof(buffer), 0);
					while (buffer[strlen(buffer) - 1] == '\n' ||
						buffer[strlen(buffer) - 1] == '\r')
					{
						buffer[strlen(buffer) - 1] = '\0';
					}
					if (client_login[i - 1] == false)
					{
						char line[1024];
						FILE* f = fopen("C:\\Temp\\user_psw.txt", "rt");
						while (!feof(f))
						{
							memset(line, 0, sizeof(line));
							fgets(line, sizeof(line), f);
							while (line[strlen(line) - 1] == '\n' ||
								line[strlen(line) - 1] == '\r')
							{
								line[strlen(line) - 1] = '\0';
							}
							if (strcmp(line, buffer) == 0)
							{
								send(client_sockets[i - 1], login, strlen(login), 0);
								client_login[i - 1] = true;
								break;
							}
						}
						fclose(f);
						if (client_login[i - 1] == false)
						{
							send(client_sockets[i - 1], invalid, strlen(invalid), 0);
						}
					}
					else
					{
						char line[1024];
						char command[1024];
						char filename[1024];
						memset(command, 0, sizeof(command));
						sprintf(command, "%s > C:\\Temp\\%d.txt", buffer, client_sockets[i-1]);
						system(command);
						memset(filename, sizeof(filename), 0);
						sprintf(filename, "C:\\Temp\\%d.txt", client_sockets[i-1]);
						FILE* f = fopen(filename, "rt");
						while (!feof(f))
						{
							memset(line, 0, sizeof(line));
							fgets(line, sizeof(line), f);
							send(client_sockets[i-1], line, strlen(line), 0);
						}
						fclose(f);
					}
				}
			}
		}
		free(events);
	}
	return 0;
}

