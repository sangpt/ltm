// ChatRoom Sample.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <WinSock2.h>

SOCKET* client_socket = NULL;
char** client_id = NULL;
int nclient = 0;

DWORD WINAPI ClientThread(LPVOID arg)
{
	SOCKET c = (SOCKET)arg;
	char* hello = "Gui id theo cu phap: client_id: abcdef\n";
	char* join = "Chuc mung! Ban da vao room\n";
	char buffer[1024];
	char id[1024];
	send(c, hello, strlen(hello), 0);
	while (true)
	{
		memset(buffer, 0, sizeof(buffer));
		recv(c, buffer, sizeof(buffer), 0);
		//Kiem tra cu phap 'client_id: xxxx'
		if (strncmp(buffer, "client_id: ", strlen("client_id: ")) == 0)
		{
			memset(id, 0, sizeof(id));
			strcpy(id, buffer + strlen("client_id: "));
			//Chap nhan client vao room, luu thong tin
			client_socket = (SOCKET*)realloc(client_socket, (nclient + 1) * sizeof(SOCKET));
			client_socket[nclient] = c;
			client_id = (char**)realloc(client_id, (nclient + 1) * sizeof(char*));
			client_id[nclient] = (char*)calloc(1024, 1);
			strcpy(client_id[nclient], id);
			nclient += 1;
			send(c, join, strlen(join), 0);
			break; //Thoat khoi vong lap yeu cau id
		}
	}
	//Vong lap trao doi du lieu
	while (true)
	{
		memset(buffer, 0, sizeof(buffer));
		recv(c, buffer, sizeof(buffer), 0);
		if (strcmp(buffer, "exit") == 0 || strcmp(buffer, "exit\n") == 0)
		{
			for (int i = 0; i < nclient; i++)
			{
				if (client_socket[i] != c) //Khong gui lai cho chinh no
				{
					char data[1024];
					memset(data, 0, sizeof(data));
					sprintf(data, "%s: da ra khoi room\n", id);
					send(client_socket[i], data, strlen(data), 0);
				}
			}
			break;
		}
		else //Gui du lieu den tat ca cac client con lai
		{
			for (int i = 0; i < nclient; i++)
			{
				if (client_socket[i] != c) //Khong gui lai cho chinh no
				{
					char data[1024];
					memset(data, 0, sizeof(data));
					sprintf(data, "%s: %s\n", id, buffer);
					send(client_socket[i], data, strlen(data), 0);
				}
			}
		}
	}

	return 0;
}

int main(int argc, char* argv[])
{
	if (argc < 2)
		return 0;
	short port = atoi(argv[1]);

	WSADATA DATA;
	WSAStartup(MAKEWORD(2, 2), &DATA);
	SOCKET s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	SOCKADDR_IN saddr;
	saddr.sin_family = AF_INET;
	saddr.sin_port = htons(port);
	saddr.sin_addr.S_un.S_addr = htonl(INADDR_ANY);
	bind(s, (sockaddr*)&saddr, sizeof(saddr));
	listen(s, 10);
	while (true)
	{ 
		SOCKADDR_IN caddr;
		int clen = sizeof(caddr);
		SOCKET c = accept(s, (sockaddr*)&caddr, &clen);
		DWORD ID = 0;
		CreateThread(NULL, 0, ClientThread, (LPVOID)c, 0, &ID);
	}
	return 0;
}

