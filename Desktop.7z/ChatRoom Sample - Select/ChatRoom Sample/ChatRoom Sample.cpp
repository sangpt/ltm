// ChatRoom Sample.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <WinSock2.h>

SOCKET* client_socket = NULL;
char** client_id = NULL;
int nclient = 0;
SOCKET* connected_socket = NULL;
int nconnected = 0;
bool* login = NULL;

int main(int argc, char* argv[])
{
	if (argc < 2)
		return 0;
	short port = atoi(argv[1]);
	char* hello = "Gui id theo cu phap: client_id: abcdef\n";
	char* join = "Chuc mung! Ban da vao room\n";
	char* invalid = "Sai cu phap! Hay nhap lai\n";
	WSADATA DATA;
	WSAStartup(MAKEWORD(2, 2), &DATA);
	SOCKET s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	SOCKADDR_IN saddr;
	saddr.sin_family = AF_INET;
	saddr.sin_port = htons(port);
	saddr.sin_addr.S_un.S_addr = htonl(INADDR_ANY);
	bind(s, (sockaddr*)&saddr, sizeof(saddr));
	listen(s, 10);
	fd_set fread;
	while (true)
	{ 
		FD_ZERO(&fread); //Lam rong tap can tham do
		FD_SET(s, &fread); //Dua s vao tap tham do
		for (int i = 0; i < nconnected; i++)
		{
			//Dua tung socket da ket noi vao tap tham do
			FD_SET(connected_socket[i], &fread);
		}
		select(0, &fread, NULL, NULL, NULL);
		if (FD_ISSET(s, &fread))
		{
			//Co them mot ket noi can accept
			SOCKADDR_IN caddr;
			int clen = sizeof(caddr);
			SOCKET c = accept(s, (sockaddr*)&caddr, &clen);
			connected_socket = (SOCKET*)realloc(connected_socket, (nconnected + 1) * sizeof(SOCKET));
			connected_socket[nconnected] = c;
			login = (bool*)realloc(login, (nconnected + 1) * sizeof(bool));
			login[nconnected] = FALSE; //Chua login
			nconnected += 1;
		}
		for (int i = 0; i < nconnected; i++)
		{
			if (FD_ISSET(connected_socket[i], &fread))
			{
				//Co du lieu tu connected_socket[i]
				char buffer[1024];
				memset(buffer, 0, sizeof(buffer));
				recv(connected_socket[i], buffer, sizeof(buffer), 0);
				if (login[i] == FALSE)
				{
					if (strncmp(buffer, "client_id: ", strlen("client_id: ")) == 0)
					{
						//Chap nhan client vao room, luu thong tin
						client_socket = (SOCKET*)realloc(client_socket, (nclient + 1) * sizeof(SOCKET));
						client_socket[nclient] = connected_socket[i];
						client_id = (char**)realloc(client_id, (nclient + 1) * sizeof(char*));
						client_id[nclient] = (char*)calloc(1024, 1);
						strcpy(client_id[nclient], buffer + strlen("client_id: "));
						nclient += 1;
						send(connected_socket[i], join, strlen(join), 0);
						login[i] = TRUE;
					}
					else
						send(connected_socket[i], invalid, strlen(invalid), 0);
				}
				else
				{
					char id[1024];
					for (int j = 0; j < nclient; j++)
					{
						if (client_socket[j] == connected_socket[i])
						{
							memset(id, 0, sizeof(id));
							strcpy(id, client_id[j]);
							break;
						}
					}

					if (strcmp(buffer, "exit") == 0 || strcmp(buffer, "exit\n") == 0)
					{
						for (int j = 0; j < nclient; j++)
						{
							if (client_socket[j] != connected_socket[i]) //Khong gui lai cho chinh no
							{
								char data[1024];
								memset(data, 0, sizeof(data));
								sprintf(data, "%s: da ra khoi room\n", id);
								send(client_socket[j], data, strlen(data), 0);
							}
						}
						break;
					}
					else //Gui du lieu den tat ca cac client con lai
					{
						for (int j = 0; j < nclient; j++)
						{
							if (client_socket[j] != connected_socket[i]) //Khong gui lai cho chinh no
							{
								char data[1024];
								memset(data, 0, sizeof(data));
								sprintf(data, "%s: %s\n", id, buffer);
								send(client_socket[j], data, strlen(data), 0);
							}
						}
					}
				}
			}
		}
	}
	return 0;
}

